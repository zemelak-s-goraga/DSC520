## DSC520
## Assignment Week 3
## Zemelak Goraga
## 2023-12-16"


```R
# Set the working directory
# setwd("labs/R101")

# Read the CSV file into a data frame as df
df <- read.csv("df.csv")

# Display the first few rows of the dataset
head(df)

```


<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Id</th><th scope=col>Id2</th><th scope=col>Geography</th><th scope=col>PopGroupID</th><th scope=col>POPGROUP.display.label</th><th scope=col>RacesReported</th><th scope=col>HSDegree</th><th scope=col>BachDegree</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>0500000US01073</td><td>1073</td><td>Jefferson County, Alabama      </td><td>1</td><td>Total population</td><td> 660793</td><td>89.1</td><td>30.5</td></tr>
	<tr><th scope=row>2</th><td>0500000US04013</td><td>4013</td><td>Maricopa County, Arizona       </td><td>1</td><td>Total population</td><td>4087191</td><td>86.8</td><td>30.2</td></tr>
	<tr><th scope=row>3</th><td>0500000US04019</td><td>4019</td><td>Pima County, Arizona           </td><td>1</td><td>Total population</td><td>1004516</td><td>88.0</td><td>30.8</td></tr>
	<tr><th scope=row>4</th><td>0500000US06001</td><td>6001</td><td>Alameda County, California     </td><td>1</td><td>Total population</td><td>1610921</td><td>86.9</td><td>42.8</td></tr>
	<tr><th scope=row>5</th><td>0500000US06013</td><td>6013</td><td>Contra Costa County, California</td><td>1</td><td>Total population</td><td>1111339</td><td>88.8</td><td>39.7</td></tr>
	<tr><th scope=row>6</th><td>0500000US06019</td><td>6019</td><td>Fresno County, California      </td><td>1</td><td>Total population</td><td> 965974</td><td>73.6</td><td>19.7</td></tr>
</tbody>
</table>



## Task 1: Data fields, their data type, and intent:

Id: Data Type: varchar (contains text and numbers) Intent: unique identifier for each row

Id2: Data Type: integer Intent: identifier for geography

Geography: Data Type: varchar (contains text) Intent: geographical location

PopGroupID: Data Type: integer Intent: identifier for population groups

POPGROUP.display-label: Data Type: varchar (contains text) Intent: display label for population groups

RacesReported: Data Type: integer Intent: total races reported

HSDegree: Data Type: float Intent: percentage of the population with a high school degree

BachDegree: Data Type: float Intent: percentage of the population with a bachelor's degree

## Task 2:Functions and their results


```R
# Load necessary library
library(ggplot2)
```


```R
# Display structure of the data frame
str(df)
```

    'data.frame':	136 obs. of  1 variable:
     $ HSDegree: num  89.1 86.8 88 86.9 88.8 73.6 74.5 77.5 84.6 80.6 ...



```R
# Display number of rows
nrow(df)
```


136



```R
# Display number of columns
ncol(df)
```


8


## Task 3: Histogram distribution of the HSDegree variable


```R
## Create Histogram
ggplot(df, aes(x = HSDegree)) +
  geom_histogram(binwidth = 2, fill = "blue", color = "black") +
  labs(title = "Distribution of High School Degrees",
       x = "Percentage of Population with High School Degree",
       y = "Frequency")

```




    
![png](output_9_1.png)
    



```R
# Summary Statistics and Skewness 

# Install the moments package
if (!requireNamespace("moments", quietly = TRUE)) {
  install.packages("moments")
}

# Load the moments package
library(moments)

# Create the dataframe
df <- data.frame(HSDegree = c(89.1, 86.8, 88, 86.9, 88.8, 73.6, 74.5, 77.5, 84.6, 80.6, 86.8, 78.6, 86.6, 88.1, 77.6, 88.1, 87.4, 87.6, 78.4, 83.6, 91.9, 85.5, 92.8, 94.1, 89.8, 89.3, 89.5, 90.1, 90.2, 91.6, 88.4, 89, 87.3, 86.3, 80.9, 87.9, 87.7, 90.1, 84.9, 88.9, 90.3, 88.4, 91.3, 88, 91.8, 85.5, 92.3, 82.9, 90.3, 90.7, 85, 95.5, 88.8, 88.5, 91.9, 90.4, 90.9, 85.5, 84.4, 82.5, 89.1, 92.3, 94.1, 92.2, 83.9, 90.1, 89.1, 89.3, 93.6, 84.9, 93.2, 89.9, 90, 93.2, 88.2, 84.5, 91.5, 88.3, 85.5, 83.4, 89.1, 93.1, 91.7, 83.8, 86.2, 88, 70.5, 90.6, 80, 90.3, 90.7, 86.8, 80.4, 89.8, 87.4, 89, 89.5, 92.4, 88.1, 90, 90.5, 89.7, 91.1, 86.8, 88.6, 91.1, 90.2, 93.9, 93.9, 92.3, 91.5, 84.9, 93.7, 82.6, 82, 86.7, 87.4, 83, 93.7, 77.6, 91.9, 75.8, 88.6, 79.8, 62.2, 85.9, 84.9, 88.6, 89.5, 93.7, 91.5, 92.3, 90.3, 92, 94.9, 86.9))

# Summary statistics
summary_stats <- summary(df$HSDegree)
print(summary_stats)

# Check skewness using moments package
skewness_value <- skewness(df$HSDegree)
print(paste("Skewness:", skewness_value))

```

    Updating HTML index of packages in '.Library'
    Making 'packages.html' ... done


       Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
      62.20   85.50   88.70   87.63   90.75   95.50 
    [1] "Skewness: -1.69340954614526"


## Task 4: Answers based on the Histogram
4.1. Is the data distribution unimodal?

Yes, the data distribution is unimodal because there is one clear peak in the histogram.

4.2. Is it approximately symmetrical?

No, the skewness value of -1.69 indicates a left-skewed (negatively skewed) distribution. This means that the left tail is longer or fatter than the right tail.


4.3. Is it approximately bell-shaped?

The histogram may suggest that it is not perfectly bell-shaped, as it is skewed.


4.4. Is it approximately normal?

No, the skewness value being significantly away from 0 and the visual inspection of the histogram suggest that the distribution is not normal.

4.5. If not normal, is the distribution skewed?

Yes, the distribution is left-skewed, as indicated by the negative skewness value (-1.69).


## Task 5: Normal curve and Histogram


```R
# 5.1. A normal curve to the Histogram.

# the dataset
HSDegree <- c(89.1, 86.8, 88, 86.9, 88.8, 73.6, 74.5, 77.5, 84.6, 80.6, 86.8, 78.6, 86.6, 88.1, 77.6, 88.1, 87.4, 87.6, 78.4, 83.6, 91.9, 85.5, 92.8, 94.1, 89.8, 89.3, 89.5, 90.1, 90.2, 91.6, 88.4, 89, 87.3, 86.3, 80.9, 87.9, 87.7, 90.1, 84.9, 88.9, 90.3, 88.4, 91.3, 88, 91.8, 85.5, 92.3, 82.9, 90.3, 90.7, 85, 95.5, 88.8, 88.5, 91.9, 90.4, 90.9, 85.5, 84.4, 82.5, 89.1, 92.3, 94.1, 92.2, 83.9, 90.1, 89.1, 89.3, 93.6, 84.9, 93.2, 89.9, 90, 93.2, 88.2, 84.5, 91.5, 88.3, 85.5, 83.4, 89.1, 93.1, 91.7, 83.8, 86.2, 88, 70.5, 90.6, 80, 90.3, 90.7, 86.8, 80.4, 89.8, 87.4, 89, 89.5, 92.4, 88.1, 90, 90.5, 89.7, 91.1, 86.8, 88.6, 91.1, 90.2, 93.9, 93.9, 92.3, 91.5, 84.9, 93.7, 82.6, 82, 86.7, 87.4, 83, 93.7, 77.6, 91.9, 75.8, 88.6, 79.8, 62.2, 85.9, 84.9, 88.6, 89.5, 93.7, 91.5, 92.3, 90.3, 92, 94.9, 86.9)

# Plot histogram
hist(HSDegree, freq = FALSE, col = "lightblue", main = "Normal Distribution Curve", xlab = "HSDegree")

# Add normal distribution curve
mu <- mean(HSDegree)
sigma <- sd(HSDegree)
x <- seq(min(HSDegree), max(HSDegree), length = 100)
y <- dnorm(x, mean = mu, sd = sigma)
lines(x, y, col = "red", lwd = 2)

```


    
![png](output_13_0.png)
    


5.2. Explain whether a normal distribution can accurately be used as a model for this data.

Given the left-skewed nature of the data, it deviates from a normal distribution. Therefore, a normal distribution may not accurately represent this data. Instead, a distribution with a left-skewed shape might be a more appropriate model.

## Task 6: Probability Plot of the HSDegree variable


```R
# Load necessary library
library(ggplot2)

ggplot(df, aes(sample = HSDegree)) +
  geom_qq() +
  geom_qq_line(color = "red") +
  labs(title = "Probability Plot of High School Degrees",
       x = "Theoretical Quantiles",
       y = "Sample Quantiles")

```




    
![png](output_16_1.png)
    


## Task 7: Descriptive statistics


```R
# Install and load the pastecs package
install.packages("pastecs")
library(pastecs)
```

    Updating HTML index of packages in '.Library'
    Making 'packages.html' ... done



```R
# Display descriptive statistics
stat.desc(df$HSDegree)
```


<style>
.dl-inline {width: auto; margin:0; padding: 0}
.dl-inline>dt, .dl-inline>dd {float: none; width: auto; display: inline-block}
.dl-inline>dt::after {content: ":\0020"; padding-right: .5ex}
.dl-inline>dt:not(:first-of-type) {padding-left: .5ex}
</style><dl class=dl-inline><dt>nbr.val</dt><dd>136</dd><dt>nbr.null</dt><dd>0</dd><dt>nbr.na</dt><dd>0</dd><dt>min</dt><dd>62.2</dd><dt>max</dt><dd>95.5</dd><dt>range</dt><dd>33.3</dd><dt>sum</dt><dd>11918</dd><dt>median</dt><dd>88.7</dd><dt>mean</dt><dd>87.6323529411765</dd><dt>SE.mean</dt><dd>0.438859785193231</dd><dt>CI.mean.0.95</dt><dd>0.867929607967526</dd><dt>var</dt><dd>26.1933159041394</dd><dt>std.dev</dt><dd>5.11794059208774</dd><dt>coef.var</dt><dd>0.0584024098442636</dd></dl>



## Task 8: Explanation of skew, kurtosis, and z-scores.

Skewness: Indicates the asymmetry of the data distribution. A   skewness value near zero suggests symmetry.

Kurtosis: Measures the tailedness of the data distribution. Positive kurtosis indicates heavier tails.

Z-scores: Measure how many standard deviations a data point is from the mean.


## Task 9: Explain how a change in the sample size may change your explanation.

Skew and Kurtosis: These are sample statistics and are influenced by sample size. Larger samples tend to stabilize these measures.

Z-scores: Generally, the z-scores become more reliable with larger sample sizes as the standard error decreases.
